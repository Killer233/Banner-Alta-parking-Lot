fx_version 'bodacious'

game 'gta5'

description 'Remove Barriers'

client_script 'client.lua'